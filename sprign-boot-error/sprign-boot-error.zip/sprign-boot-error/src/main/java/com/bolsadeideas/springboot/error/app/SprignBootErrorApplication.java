package com.bolsadeideas.springboot.error.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprignBootErrorApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprignBootErrorApplication.class, args);
	}

}

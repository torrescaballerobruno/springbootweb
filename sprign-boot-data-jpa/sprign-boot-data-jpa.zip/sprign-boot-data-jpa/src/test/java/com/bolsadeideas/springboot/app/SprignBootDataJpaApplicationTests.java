package com.bolsadeideas.springboot.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprignBootDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
